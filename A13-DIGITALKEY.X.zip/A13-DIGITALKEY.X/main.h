/* 
 * File:   main.h
 * Author: HP
 *
 * Created on 4 July, 2024, 10:27 PM
 */

#ifndef MAIN_H
#define	MAIN_H

#define OFF              0x00

#define  LED_ARRAY_1      PORTD
#define  LED_ARRAY_1_DDR  TRISD

#endif	/* MAIN_H */

