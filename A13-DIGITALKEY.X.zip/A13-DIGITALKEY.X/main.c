/*/*
 * File:   main.c
 * Author: SANATH SHETTY P
 * DESCRIPTION : Implement a 4 digit key press counter
 * Created on 5 July, 2024, 11:07 AM
 */

#include <xc.h>
#include "ssd.h"
#include "main.h"
#include "digital_keypad.h"

#pragma config WDTE = OFF // Watchdog Timer Enable bit (WDT disabled)

static void init_config(void) {
    init_ssd();
    init_digital_keypad();
}

void main(void) {
    unsigned char ssd[] = {ZERO, ZERO, ZERO, ZERO};
    unsigned char digit[] = {ZERO, ONE, TWO, THREE, FOUR, FIVE, SIX, SEVEN, EIGHT, NINE};
    static unsigned int count = 0, delay = 0;
    unsigned char key;
    init_config();

    while (1) {
        key = read_digital_keypad(LEVEL);

        if (key == SW1) {
            delay++; // Increment the counter
        } else {
            // Only reset the counter if SW1 was previously pressed
            if (delay > 0) {
                if (delay >= 200) {
                    count = 0; // Reset count to 0
                }
                delay = 0; // Reset the counter
            }
        }

        // Increment count if SW1 was previously pressed
        if (delay == 1) {
            if (count >= 9999) {
                count = 0;
            } else {
                count++;
            }
        }

        // Update SSD display
        ssd[3] = digit[count % 10];
        ssd[2] = digit[(count / 10) % 10];
        ssd[1] = digit[(count / 100) % 10];
        ssd[0] = digit[count / 1000];

        // Display current count on SSD
        display(ssd);
    }
    return;
}
