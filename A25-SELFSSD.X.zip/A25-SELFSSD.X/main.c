/*
 * File:   main.c
 * Author: SANATH SHETTY P
 * DESCRIPTION: Self counter using SSDs with storage on key press
 *
 * Created on 5 July, 2024, 11:07 AM
 */

#include <xc.h>
#include "ssd.h"
#include "digital_keypad.h"

#pragma config WDTE = OFF // Watchdog Timer Enable bit (WDT disabled)

static void init_config(void) {
    init_digital_keypad();
    init_ssd();
}

void main(void) {
    init_config();

    static unsigned char ssd[MAX_SSD_CNT] = {ZERO, ZERO, ZERO, ZERO};
    static unsigned char digit[] = {ZERO, ONE, TWO, THREE, FOUR, FIVE, SIX, SEVEN, EIGHT, NINE};
    static unsigned int count = 0;
    unsigned int delay = 0;
    unsigned char key;

    // Read count from EEPROM on startup
    count = 1000 * eeprom_read(0x03) + 100 * eeprom_read(0x02) + 10 * eeprom_read(0x01) + eeprom_read(0x00);

    while (1) {
        key = read_digital_keypad(STATE);

        // Check if SW2 is pressed to store count in EEPROM
        if (key == SW2) {
            // Store count in EEPROM
            eeprom_write(0x03, (count / 1000) % 10); // Thousands place
            eeprom_write(0x02, (count / 100) % 10); // Hundreds place
            eeprom_write(0x01, (count / 10) % 10); // Tens place
            eeprom_write(0x00, count % 10); // Units place 
        }

        // Logic for self counter (approximately 1 second delay)
        if (delay++ == 100) {
            delay = 0;

            if (count >= 9999) {
                count = 0;
            } else {
                count++;
            }
        }

        // Update SSD display
        ssd[3] = digit[count % 10]; // count%10 : 7 : digits[count%10] : digits[7]
        ssd[2] = digit[(count / 10) % 10]; //count/10 : 456%10 : 6
        ssd[1] = digit[(count / 100) % 10]; //count/100: 45%10 : 5
        ssd[0] = digit[count / 1000];

        // Display current count on SSD
        display(ssd);
    }
}