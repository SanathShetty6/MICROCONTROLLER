/*
 * File:   main.c
 * Author: Sanath Shetty P
 * Description: Implement multiple patterns on LEDs controlled by switches
 * Created on 2 July, 2024, 10:14 PM
 */

#include <xc.h>
#include "main.h"
#include "digitalkeypad.h"

#pragma config WDTE = OFF  

static void init_config(void) {
    /*To keep all LEDS OFF */
    LED_ARRAY_1 = OFF;

    /*To configure PORTD as output PORT*/
    LED_ARRAY_1_DDR = 0x00;

    /* Initializing digital keypad */
    init_digital_keypad();

}

void main(void) {
    //Variable declaration
    // Variable declaration
    unsigned char key, key_copy;
    unsigned long int delay = 10000;
    unsigned int i = 0;
    unsigned char flag = 0;


    init_config();

    while (1) {

        /*To read key press*/
        key_copy = read_digital_keypad(LEVEL);

        /*If switch is pressed, then only update key_copy*/
        if (key_copy != ALL_RELEASED) {
            key = key_copy;
        }

        /*using non blocking delay*/
        if (delay++ == 10000) {
            delay = 0;
            flag = !flag;
            /*top to bottom and bottom to top LED'S blinking*/
            if (key == SW1) {
                if (i < 8) {
                    LED_ARRAY_1 = (LED_ARRAY_1 << 1) | 0x01; // Shift LED upto down
                    i++;
                }// OFF the LED from up to down
                else if (i > 7 && i < 16) {
                    LED_ARRAY_1 = LED_ARRAY_1 << 1; // Shift left
                    i++;
                }//Blink LED from dwon to up
                else if (i > 15 && i < 24) {
                    LED_ARRAY_1 = (LED_ARRAY_1 >> 1) | 0x80; // Shift from down to UP
                    i++;
                }// OFF the LED after the blinking upwards
                else if (i > 23 && i < 32) {
                    LED_ARRAY_1 = LED_ARRAY_1 >> 1;
                    i++;
                } else {
                    i = 0; // Reset i for the next cycle
                }

            }/*top to bottom  LED'S blinking*/
            else if (key == SW2) {


                if (i < 8) {
                    LED_ARRAY_1 = (LED_ARRAY_1 << 1) | 0x01; // Shift LED left
                    i++;
                } else if (i >7 && i < 16) {
                    LED_ARRAY_1 = LED_ARRAY_1 << 1; // Shift left
                    i++;
                } else {
                    i = 0; // Reset i for the next cycle
                    LED_ARRAY_1 = OFF; // Turn off all LEDs
                }
            }                /*Alternative LED'S blinking*/
            else if (key == SW3) {
                if (flag) {
                    LED_ARRAY_1 = 0xAA;
                } else {
                    LED_ARRAY_1 = ~LED_ARRAY_1;
                }
            }/*Nibble LEDI'S blinking*/
            else if (key == SW4) {
                if (flag) {
                    LED_ARRAY_1 = 0x0F;
                } else {
                    LED_ARRAY_1 = ~LED_ARRAY_1;
                }

            }/*user pressed above SW4 whether turn off the LED'S*/
            else {
                LED_ARRAY_1 = OFF;
            }
        }
    }
    return;
}
