/* 
 * File:   main.h
 * Author: HP
 *
 * Created on 3 July, 2024, 11:44 AM
 */

#ifndef MAIN_H
#define	MAIN_H

#define LED_ARRAY_1         PORTD
#define LED_ARRAY_1_DDR     TRISD

#define OFF                 0x00
//void pattern(void);

#endif	/* MAIN_H */

