#include <xc.h>
#include "main.h"
#include "digital_keypad.h"

#pragma config WDTE = OFF // Watchdog Timer Enable bit (WDT disabled)

static void init_config(void) {
    /* To keep all LEDs OFF */
    LED_ARRAY_1 = OFF;

    /* To configure PORTD as output PORT */
    LED_ARRAY_1_DDR = OFF;

    /* Initializing digital keypad */
    init_digital_keypad();
}

void pattern(void) {
    long int delay = 0;
    int i = 0;
    while (1) {
        if (delay++ == 10000) {
            delay = 0;
            if (i < 8) {
                LED_ARRAY_1 = (LED_ARRAY_1 << 1) | 0x01; // Shift LED up to down
                i++;
            } else if (i > 7 && i < 16) {
                LED_ARRAY_1 = LED_ARRAY_1 << 1; // Shift left
                i++;
            } else if (i > 15 && i < 24) {
                LED_ARRAY_1 = (LED_ARRAY_1 >> 1) | 0x80; // Shift from down to up
                i++;
            } else if (i > 23 && i < 32) {
                LED_ARRAY_1 = LED_ARRAY_1 >> 1;
                i++;
            } else {
                i = 0; // Reset i for the next cycle
            }
        }

        unsigned char key = read_digital_keypad(STATE);
        if (key == SW1) {
            return; // Exit the pattern function when SW1 is pressed
        }
    }
}

void main(void) {
    unsigned char key;
    unsigned long int delay = 0;
    unsigned char dir_f = 1; // 1: left to right, 0: right to left
    int i = 0;
    int pattern_mode = 1; // 1: pattern mode, 0: direction mode

    init_config();

    while (1) {
        if (pattern_mode) {
            pattern();
            pattern_mode = 0; // Switch to direction mode after pattern
        }

        key = read_digital_keypad(STATE);

        if (key == SW1) {
            // Modify the direction flag and switch to direction mode
            dir_f = !dir_f;
            i = 0; // Reset the counter to start the new pattern direction
            pattern_mode = 0;
        }

        if (delay++ == 10000) {
            delay = 0;

            if (dir_f == 1) {
                // Turn on and off LEDs from left to right
                if (i < 8) {
                    LED_ARRAY_1 = (LED_ARRAY_1 << 1) | 0x01; // Turn on i LEDs
                    i++;
                } else if (i > 7 && i < 16) {
                    LED_ARRAY_1 = LED_ARRAY_1 << 1;
                    i++;
                } else {
                    i = 0;
                }
            } else if (dir_f == 0) {
                // Turn on and off LEDs from right to left
                if (i < 8) {
                    LED_ARRAY_1 = (LED_ARRAY_1 >> 1) | 0x80; // Turn on i LEDs
                    i++;
                } else if (i > 7 && i < 16) {
                    LED_ARRAY_1 = LED_ARRAY_1 >> 1;
                    i++;
                } else {
                    i = 0;
                }
            }
        }
    }
}
