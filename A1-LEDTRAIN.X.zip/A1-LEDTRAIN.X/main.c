/*
 * File:   main.c
 * Author: SANATH SHETTY .P.
 * DESCRIPTION: Implement LED train pattern on LED
 *
 * Created on 27 June, 2024, 10:35 AM
 */

#include <xc.h>
#pragma config WDTE = OFF // Watchdog Timer Enable bit (WDT disabled)

static void init_config(void) {
    // Write initialization code here
    PORTB = 0x00; // Initialize PORTB to 0
    TRISB = 0x00; // Set PORTB as output
}

void main(void) {
    long int delay = 0;
    int i = 0;
    init_config();
    while (1) {
        if (delay++ == 50000) {
            delay = 0;
            if (i < 8) {
                PORTB = (PORTB << 1) | 0x01; // Shift LED upto down
                i++;
            }
            // OFF the LED from up to down
            else if (i > 7 && i < 16) {
                PORTB = PORTB << 1; // Shift left
                i++;
            }
            //Blink LED from dwon to up
            else if (i >15 && i < 24) {
                PORTB = (PORTB >> 1) | 0x80; // Shift from down to UP
                i++;
            }
            // OFF the LED after the blinking upwards
            else if (i > 23 && i < 32) {
                PORTB = PORTB >> 1; 
                i++;
            }
            else {
                i = 0; // Reset i for the next cycle
            }
        }
    }
}
